//hello world program
console.log('Hello World');
